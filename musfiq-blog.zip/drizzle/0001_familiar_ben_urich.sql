CREATE TABLE `blog_posts` (
	`id` varchar(36) NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`content` text NOT NULL,
	`image` text,
	`category` varchar(50) NOT NULL DEFAULT 'Personal',
	`tags` text,
	`date` varchar(10) NOT NULL,
	`featured` boolean NOT NULL DEFAULT false,
	`published` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `blog_posts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `news_links` (
	`id` varchar(36) NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`url` text NOT NULL,
	`category` varchar(50) NOT NULL DEFAULT 'Other',
	`source` varchar(255),
	`date` varchar(10) NOT NULL,
	`featured` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `news_links_id` PRIMARY KEY(`id`)
);
