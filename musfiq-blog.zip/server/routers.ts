import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getAllBlogPosts, getBlogPostById, createBlogPost, updateBlogPost, deleteBlogPost, getAllNewsLinks, getNewsLinkById, createNewsLink, updateNewsLink, deleteNewsLink } from "./db";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  blog: router({
    list: publicProcedure.query(() => getAllBlogPosts()),
    getById: publicProcedure.input(z.string()).query(({ input }) => getBlogPostById(input)),
    create: protectedProcedure.input(z.object({
      title: z.string(),
      description: z.string().optional(),
      content: z.string(),
      image: z.string().optional(),
      category: z.string().default("Personal"),
      tags: z.string().optional(),
      date: z.string(),
      featured: z.boolean().default(false),
      published: z.boolean().default(false),
    })).mutation(({ input }) => createBlogPost({
      id: nanoid(),
      ...input,
    })),
    update: protectedProcedure.input(z.object({
      id: z.string(),
      title: z.string().optional(),
      description: z.string().optional(),
      content: z.string().optional(),
      image: z.string().optional(),
      category: z.string().optional(),
      tags: z.string().optional(),
      date: z.string().optional(),
      featured: z.boolean().optional(),
      published: z.boolean().optional(),
    })).mutation(({ input }) => {
      const { id, ...updates } = input;
      return updateBlogPost(id, updates);
    }),
    delete: protectedProcedure.input(z.string()).mutation(({ input }) => deleteBlogPost(input)),
  }),

  news: router({
    list: publicProcedure.query(() => getAllNewsLinks()),
    getById: publicProcedure.input(z.string()).query(({ input }) => getNewsLinkById(input)),
    create: protectedProcedure.input(z.object({
      title: z.string(),
      description: z.string().optional(),
      url: z.string(),
      category: z.string().default("Other"),
      source: z.string().optional(),
      date: z.string(),
      featured: z.boolean().default(false),
    })).mutation(({ input }) => createNewsLink({
      id: nanoid(),
      ...input,
    })),
    update: protectedProcedure.input(z.object({
      id: z.string(),
      title: z.string().optional(),
      description: z.string().optional(),
      url: z.string().optional(),
      category: z.string().optional(),
      source: z.string().optional(),
      date: z.string().optional(),
      featured: z.boolean().optional(),
    })).mutation(({ input }) => {
      const { id, ...updates } = input;
      return updateNewsLink(id, updates);
    }),
    delete: protectedProcedure.input(z.string()).mutation(({ input }) => deleteNewsLink(input)),
  }),
});

export type AppRouter = typeof appRouter;
